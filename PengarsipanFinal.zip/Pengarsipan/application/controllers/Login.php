<?php
// Metode yang digunakan pada Halaman Default saat pertama masuk
class Login extends CI_Controller {

  //halaman index untuk kontroller login -> menampilkan view 'login/index'
  public function index(){

    // panggil method getKategori() di kategori_model untuk membaca data list kategori dari tabel kategori untuk ditampilkan ke view
    $data['kategori'] = $this->book_model->getKategori();

    $this->load->view('umum/header');
    $this->load->view('umum/index', $data);
  }

  // method untuk proses submit login
  public function submit(){
    
    // baca data username dan password dari form login
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    // panggil method getUserProfile() dari user_model untuk membaca data profile user
    $data['user'] = $this->user_model->getUserProfile($username);
      
      // bandingkan password user dari database dengan yang disubmit via form
      if ($data['user']['passwd'] == $password){
      
        // jika password sama, maka simpan username dan fullname user ke session
        $_SESSION['username'] = $username;
        $_SESSION['full'] = $data['user']['nama'];
        $_SESSION['role'] = $data['user']['role'];
                
                if ($data['user']['role'] == 'Administrator'){
                    $sql = $this->load->view('administrator/header');
                    $sql = $this->load->view('administrator/index');
                    // Cek apakah query insert nya sukses atau gagal // Jika sukses
                      echo "<script>alert('Login Berhasil! Selamat Datang, Administrator!');window.location = '".base_url('administrator/index')."';</script>";
                } else {
                    echo "<script>alert('Login Berhasil! Selamat Datang, Selamat Bertugas!');window.location = '".base_url('admin/index')."';</script>";
                }
      } else {
        // jika password tidak sama, arahkan ke kontroler 'login/index' lagi
        echo "<script>alert('Login Gagal!');window.location = '".base_url('login/index')."';</script>";
        }

  }

}
?>