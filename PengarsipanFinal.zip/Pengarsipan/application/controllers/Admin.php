<?php
// Metode yang digunakan untuk menampilkan view halaman untuk admin

class Admin extends CI_Controller { 

    public function __construct(){
       parent::__construct();
           if (!isset($_SESSION['username'])){
            
            // jika session 'username' blm ada, maka arahkan ke kontroller 'login'
            redirect('login');
        }
    }

	// halaman index dari admin
    public function index(){

        // panggil method getKategori() di kategori_model untuk membaca data list kategori dari tabel kategori untuk ditampilkan ke view
        $data['kategori'] = $this->book_model->getKategori();
        $data['nama'] = $_SESSION['full'];
        $data['role'] = $_SESSION['role'];


        // tampilkan view 'admin/index'
        $this->load->view('admin/header', $data);
        $this->load->view('admin/index', $data);
    }

    // halaman help dari admin
    public function help(){
        $data['nama'] = $_SESSION['full'];
        $data['role'] = $_SESSION['role'];

        // tampilkan view 'admin/help'
        $this->load->view('admin/header', $data);
        $this->load->view('admin/help');
    }

    // halaman add dari admin
    public function add(){

        // panggil method getKategori() di kategori_model untuk membaca data list kategori dari tabel kategori untuk ditampilkan ke view
        $data['kategori'] = $this->book_model->getKategori();
        $data['nama'] = $_SESSION['full'];
        $data['role'] = $_SESSION['role'];

        // tampilkan view 'admin/add'
        $this->load->view('admin/header', $data);
        $this->load->view('admin/add', $data);
    }

    // halaman about dari admin
    public function about(){
        $data['nama'] = $_SESSION['full'];
        $data['role'] = $_SESSION['role'];
        
        // tampilkan view 'admin/about'
        $this->load->view('admin/header', $data);
        $this->load->view('admin/about');
    }

    // halaman kategori dari admin
    public function kategori(){

        // panggil method getKategori() di kategori_model untuk membaca data list kategori dari tabel kategori untuk ditampilkan ke view
        $data['kategori'] = $this->book_model->getKategori();
        $data['nama'] = $_SESSION['full'];
        $data['role'] = $_SESSION['role'];
        
        // tampilkan view 'admin/kategori'
        $this->load->view('admin/header', $data);
        $this->load->view('admin/addkategori', $data);
    }

    // halaman tambah dari admin
    public function tambah(){
        // baca data username dan password dari form login
        $idkategori = $_POST['idkategori'];
        
        // bandingkan password user dari database dengan yang disubmit via form
        if ($idkategori == 1){
                // panggil method getKategori() di kategori_model untuk membaca data list kategori dari tabel kategori untuk ditampilkan ke view
            $data['kategori'] = $this->book_model->getKategori();
            $data['nama'] = $_SESSION['full'];
            $data['role'] = $_SESSION['role'];

            // jika password sama, maka simpan username dan fullname user ke session
            $this->load->view('admin/header', $data);
            $this->load->view('admin/addbuku', $data);
            
        } elseif ($idkategori == 2) {
            // panggil method getKategori() di kategori_model untuk membaca data list kategori dari tabel kategori untuk ditampilkan ke view
            $data['kategori'] = $this->book_model->getKategori();
            $data['nama'] = $_SESSION['full'];
            $data['role'] = $_SESSION['role'];

            // jika password tidak sama, arahkan ke kontroler 'login/index' lagi
            $this->load->view('admin/header', $data);
            $this->load->view('admin/adddokumen', $data);

        } elseif ($idkategori == 3) {
            // panggil method getKategori() di kategori_model untuk membaca data list kategori dari tabel kategori untuk ditampilkan ke view
            $data['kategori'] = $this->book_model->getKategori();
            $data['nama'] = $_SESSION['full'];
            $data['role'] = $_SESSION['role'];

            // jika password tidak sama, arahkan ke kontroler 'login/index' lagi
            $this->load->view('admin/header', $data);
            $this->load->view('admin/addlaporan', $data);

        } elseif ($idkategori == 4) {
            // panggil method getKategori() di kategori_model untuk membaca data list kategori dari tabel kategori untuk ditampilkan ke view
            $data['kategori'] = $this->book_model->getKategori();
            $data['nama'] = $_SESSION['full'];
            $data['role'] = $_SESSION['role'];

            // jika password tidak sama, arahkan ke kontroler 'login/index' lagi
            $this->load->view('admin/header', $data);
            $this->load->view('admin/addsurat', $data);
            
        } else {
            // panggil method getKategori() di kategori_model untuk membaca data list kategori dari tabel kategori untuk ditampilkan ke view
            $data['kategori'] = $this->book_model->getKategori();
            $data['nama'] = $_SESSION['full'];
            $data['role'] = $_SESSION['role'];

            // jika password tidak sama, arahkan ke kontroler 'login/index' lagi
            $this->load->view('admin/header', $data);
            $this->load->view('admin/addlainnya', $data);
        }
    }

        // method untuk mencari data buku berdasarkan 'key'
    public function search(){
        
        // baca key dari form cari data
        $key = $_POST['key'];
        $_SESSION['key'] = $key;


        // panggil method findBook() dari model book_model untuk menjalankan query cari data
        $data['book'] = $this->book_model->findBook($key);
        $data['totalArsip'] = $this->book_model->hitungJumlah();
        $data['nama'] = $_SESSION['full'];
        $data['role'] = $_SESSION['role'];

        // tampilkan hasil pencarian di view 'dashboard/admin'
        $this->load->view('admin/header', $data);
        $this->load->view('admin/result', $data);
    }

    // method hapus data arsip berdasarkan id
    public function delete($id){
        $this->book_model->delBook($id);
        $key = $_SESSION['key'];
        $data['nama'] = $_SESSION['full'];
        $data['role'] = $_SESSION['role'];

        // panggil method findBook() dari model book_model untuk menjalankan query cari data
        $data['book'] = $this->book_model->findBook($key);
        
        // tampilkan hasil pencarian di view 'dashboard/admin'
        redirect('admin/search');
    }

public function edit($id){
        
        // baca data username dan password dari form login        
        $data['view_book'] = $this->book_model->showBook($id);
        $kateg = $data['view_book']['idkategori'];
        $_SESSION['kat'] = $kateg;
        
        // bandingkan password user dari database dengan yang disubmit via form
        if ($kateg == 'Buku'){
            // panggil method getKategori() dan showBook() di book_model untuk membaca data list kategori dari tabel kategori dan mengambil data dokumen dari tabel untuk ditampilkan ke view
            $data['view_book'] = $this->book_model->showBook($id);
            $data['nama'] = $_SESSION['full'];
            $data['role'] = $_SESSION['role'];
    
            $data['nomor'] = $data['view_book']['nomor'];
            $data['departemen'] = $data['view_book']['departemen'];
            $data['judul'] = $data['view_book']['judul'];
            $data['tahun'] = $data['view_book']['thn'];
            $data['lokasi'] = $data['view_book']['lokasi'];
            $data['tglmasuk'] = $data['view_book']['tglmasuk'];
            
            // tampilkan hasil pencarian di view 'dashboard/admin'
            $this->load->view('admin/header', $data);
            $this->load->view('admin/editbuku', $data);
            
        } elseif ($kateg == 'Dokumen') {
            // panggil method getKategori() dan showBook() di book_model untuk membaca data list kategori dari tabel kategori dan mengambil data dokumen dari tabel untuk ditampilkan ke view
            $data['docs'] = $this->book_model->ddoc($id);
            $data['nama'] = $_SESSION['full'];
            $data['role'] = $_SESSION['role'];
    
            $data['nomor'] = $data['docs']['nomor'];
            $data['departemen'] = $data['docs']['departemen'];
            $data['judul'] = $data['docs']['judul'];
            $data['tahun'] = $data['docs']['thn'];
            $data['lokasi'] = $data['view_book']['lokasi'];
            $data['tglmasuk'] = $data['docs']['tglmasuk'];
            
            // tampilkan hasil pencarian di view 'dashboard/admin'
            $this->load->view('admin/header', $data);
            $this->load->view('admin/editdokumen', $data);

        } elseif ($kateg == 'Laporan') {
            // panggil method getKategori() dan showBook() di book_model untuk membaca data list kategori dari tabel kategori dan mengambil data dokumen dari tabel untuk ditampilkan ke view
            $data['laps'] = $this->book_model->llap($id);
            $data['nama'] = $_SESSION['full'];
            $data['role'] = $_SESSION['role'];
    
            $data['nomor'] = $data['laps']['nomor'];
            $data['departemen'] = $data['laps']['departemen'];
            $data['judul'] = $data['laps']['judul'];
            $data['tahun'] = $data['laps']['thn'];
            $data['lokasi'] = $data['laps']['lokasi'];
            $data['tglmasuk'] = $data['laps']['tglmasuk'];
            
            // tampilkan hasil pencarian di view 'dashboard/admin'
            $this->load->view('admin/header', $data);
            $this->load->view('admin/editlaporan', $data);

        } elseif ($kateg == 'Surat') {
            // panggil method getKategori() dan showBook() di book_model untuk membaca data list kategori dari tabel kategori dan mengambil data dokumen dari tabel untuk ditampilkan ke view
            $data['kategori'] = $this->book_model->getKategori();
            $data['mails'] = $this->book_model->ssurat($id);
            $data['nama'] = $_SESSION['full'];
            $data['role'] = $_SESSION['role'];
    
            $data['nomor'] = $data['view_book']['nomor'];
            $data['departemen'] = $data['view_book']['departemen'];
            $data['judul'] = $data['view_book']['judul'];
            $data['tahun'] = $data['view_book']['thn'];
            $data['dari'] = $data['mails']['dari'];
            $data['lokasi'] = $data['view_book']['lokasi'];
            $data['kepada'] = $data['mails']['kepada'];
            $data['tglmasuk'] = $data['mails']['tglmasuk'];
            $data['nomorsurat'] = $data['mails']['nomorsurat'];
            $data['jenis'] = $data['mails']['jenis'];
            $data['klasifikasi'] = $data['mails']['klasifikasi'];
            $data['lampiran'] = $data['mails']['lampiran'];
            $data['tglsurat'] = $data['mails']['tglsurat'];
            
            // tampilkan hasil pencarian di view 'dashboard/admin'
            $this->load->view('admin/header', $data);
            $this->load->view('admin/editsurat', $data);
            
        } else {
            // panggil method getKategori() dan showBook() di book_model untuk membaca data list kategori dari tabel kategori dan mengambil data dokumen dari tabel untuk ditampilkan ke view
            $data['kategori'] = $this->book_model->getKategori();
            $data['view_book'] = $this->book_model->showBook($id);
            $data['lains'] = $this->book_model->llain($id);
            $data['nama'] = $_SESSION['full'];
            $data['role'] = $_SESSION['role'];
    
            $data['nomor'] = $data['view_book']['nomor'];
            $data['departemen'] = $data['view_book']['departemen'];
            $data['judul'] = $data['view_book']['judul'];
            $data['tahun'] = $data['view_book']['thn'];
            $data['tglmasuk'] = $data['view_book']['tglmasuk'];
            $data['lokasi'] = $data['view_book']['lokasi'];

            // tampilkan hasil pencarian di view 'dashboard/admin'
            $this->load->view('admin/header', $data);
            $this->load->view('admin/editlainnya', $data);
        }
    }

    // halaman peminjam dari admin
    public function peminjaman($id){
        $data['nama'] = $_SESSION['full'];
        $data['role'] = $_SESSION['role'];
        $data['view_book'] = $this->book_model->showBook($id);
        $data['nomor'] = $data['view_book']['nomor'];
        $data['departemen'] = $data['view_book']['departemen'];

        // tampilkan view 'admin/peminjam'
        $this->load->view('admin/header', $data);
        $this->load->view('admin/peminjam', $data);
    }

    // halaman kembali dari admin
    public function kembali($id){
        $tglkembali = date('j F Y');

        $key = $_SESSION['key'];
        $data['nama'] = $_SESSION['full'];
        $data['role'] = $_SESSION['role'];

        // panggil method findBook() dari model book_model untuk menjalankan query cari data
        $data['book'] = $this->book_model->findBook($key);
        $data['totalArsip'] = $this->book_model->hitungJumlah();
        
        $this->book_model->kembali($id, $tglkembali);
        // tampilkan hasil pencarian di view 'dashboard/admin'
        redirect('admin/search');
    }

    public function detailpinjam($id){
        $data['view_det'] = $this->book_model->getpe($id);

        // tampilkan view 'admin/peminjam'
        $this->load->view('admin/detail', $data);
    }

    public function detailsurat($id){
        $data['view_det'] = $this->book_model->getsurat($id);

        // tampilkan view 'admin/peminjam'
        $this->load->view('admin/detailsurat', $data);
    }

        // halaman index dari admin
    public function histori(){
        $data['nama'] = $_SESSION['full'];
        $data['role'] = $_SESSION['role'];

        $data['view'] = $this->book_model->gethis();

        // tampilkan view 'admin/index'
        $this->load->view('admin/header', $data);
        $this->load->view('admin/history', $data);
    }

            // halaman index dari admin
    public function cari(){

        $law = $_POST['law'];
        $_SESSION['law'] = $law;

        $data['nama'] = $_SESSION['full'];
        $data['role'] = $_SESSION['role'];

        $data['view'] = $this->book_model->searchist($law);

        // tampilkan view 'admin/index'
        $this->load->view('admin/header', $data);
        $this->load->view('admin/history', $data);
    }

    // method untuk proses logout
    public function logout(){
        // hapus seluruh data session
        session_destroy();
        // redirect ke kontroller 'login'
        redirect('guest');
   }
}
?>