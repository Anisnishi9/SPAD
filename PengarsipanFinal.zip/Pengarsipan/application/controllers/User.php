<?php
// Metode yang digunakan pada bagian ADDADMIN

class User extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('user_model'); 

		// cek keberadaan session 'username'	
		if (!isset($_SESSION['username'])){

			// jika session 'username' blm ada, maka arahkan ke kontroller 'login'
			redirect('login');
		}
	}

	// method hapus data buku berdasarkan id
	public function delete($id){
		
		$this->user_model->delUser($id);
		// arahkan untuk me reload halaman
		redirect('administrator/admin');
	}

	// method untuk tambah data admin 
	public function insert(){

		// baca data dari 
		$uname = $_POST['uname'];
		$pass = $_POST['pass'];
		$kewe = $_POST['kewe'];
		$full = $_POST['full'];

		// panggil method insertUser() di model 'user_model' untuk menjalankan query insert
		$this->user_model->insertUser($uname, $pass, $full, $kewe);

		// arahkan untuk me reload halaman 
		redirect('administrator/admin');
	}
}
?>