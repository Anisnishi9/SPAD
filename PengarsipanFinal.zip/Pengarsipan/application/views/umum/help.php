
<div class="w3-container">   

	<!--CONTENT-->	
	<div class="w3-col" align="center">
		<h2 style="padding-left:0">PENCARIAN</h2>
		<p style="padding-left:0">Metode pencarian arsip yang tersedia di Sistem Pengarsipan Pemerintah Kabupaten Sukoharjo dapat dilakukan oleh pengguna <br> dengan memasukkan kata kunci apapun, baik itu yang terkandung dalam judul arsip maupun berdasarkan <br> jenis kategori arsip yang hendak dicari lalu tekan enter.</p>
	</div>
	<!--END CONTENT-->

</div>

</body>
</html>