<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1">

<head>
<link rel="shortcut icon" href="<?php echo base_url();?>assets/img/logozz.png">
</head>

<link href="<?php echo base_url();?>assets/css/w3responsiv.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url();?>assets/css/sidenav.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url();?>assets/css/pop.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url();?>assets/css/svg.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url();?>assets/css/dashboard.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url();?>assets/css/table.css" rel="stylesheet" type="text/css" />

<script>
    function openNav() {
      document.getElementById("mySidenav").style.width = "250px";
  }

  function closeNav() {
      document.getElementById("mySidenav").style.width = "0";
  }

  var modal = document.getElementById('id01');
  window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>

<title>SISTEM PENYIMPANAN ARSIP </title>
    <!--SIDENAV OVERLAY-->
    <div class="w3-container w3-light-blue">
        <div id="mySidenav" class="sidenav" style="overflow-x: hidden;">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
            
            <a><h3>MENU<h3></a>
        
        <div class="underline"></div>

            <a href="<?php echo site_url('guest/'); ?>">
                <svg class="svg-iconb" viewBox="0 0 20 20">
                    <path d="M18.121,9.88l-7.832-7.836c-0.155-0.158-0.428-0.155-0.584,0L1.842,9.913c-0.262,0.263-0.073,0.705,0.292,0.705h2.069v7.042c0,0.227,0.187,0.414,0.414,0.414h3.725c0.228,0,0.414-0.188,0.414-0.414v-3.313h2.483v3.313c0,0.227,0.187,0.414,0.413,0.414h3.726c0.229,0,0.414-0.188,0.414-0.414v-7.042h2.068h0.004C18.331,10.617,18.389,10.146,18.121,9.88 M14.963,17.245h-2.896v-3.313c0-0.229-0.186-0.415-0.414-0.415H8.342c-0.228,0-0.414,0.187-0.414,0.415v3.313H5.032v-6.628h9.931V17.245z M3.133,9.79l6.864-6.868l6.867,6.868H3.133z">
                    </path>
                </svg>&nbsp; Beranda</a>

            <a href="<?php echo site_url('guest/help'); ?>">
                <svg class="svg-iconb" viewBox="0 0 20 20">
                    <path d="M8.627,7.885C8.499,8.388,7.873,8.101,8.13,8.177L4.12,7.143c-0.218-0.057-0.351-0.28-0.293-0.498c0.057-0.218,0.279-0.351,0.497-0.294l4.011,1.037C8.552,7.444,8.685,7.667,8.627,7.885 M8.334,10.123L4.323,9.086C4.105,9.031,3.883,9.162,3.826,9.38C3.769,9.598,3.901,9.82,4.12,9.877l4.01,1.037c-0.262-0.062,0.373,0.192,0.497-0.294C8.685,10.401,8.552,10.18,8.334,10.123 M7.131,12.507L4.323,11.78c-0.218-0.057-0.44,0.076-0.497,0.295c-0.057,0.218,0.075,0.439,0.293,0.495l2.809,0.726c-0.265-0.062,0.37,0.193,0.495-0.293C7.48,12.784,7.35,12.562,7.131,12.507M18.159,3.677v10.701c0,0.186-0.126,0.348-0.306,0.393l-7.755,1.948c-0.07,0.016-0.134,0.016-0.204,0l-7.748-1.948c-0.179-0.045-0.306-0.207-0.306-0.393V3.677c0-0.267,0.249-0.461,0.509-0.396l7.646,1.921l7.654-1.921C17.91,3.216,18.159,3.41,18.159,3.677 M9.589,5.939L2.656,4.203v9.857l6.933,1.737V5.939z M17.344,4.203l-6.939,1.736v9.859l6.939-1.737V4.203z M16.168,6.645c-0.058-0.218-0.279-0.351-0.498-0.294l-4.011,1.037c-0.218,0.057-0.351,0.28-0.293,0.498c0.128,0.503,0.755,0.216,0.498,0.292l4.009-1.034C16.092,7.085,16.225,6.863,16.168,6.645 M16.168,9.38c-0.058-0.218-0.279-0.349-0.498-0.294l-4.011,1.036c-0.218,0.057-0.351,0.279-0.293,0.498c0.124,0.486,0.759,0.232,0.498,0.294l4.009-1.037C16.092,9.82,16.225,9.598,16.168,9.38 M14.963,12.385c-0.055-0.219-0.276-0.35-0.495-0.294l-2.809,0.726c-0.218,0.056-0.351,0.279-0.293,0.496c0.127,0.506,0.755,0.218,0.498,0.293l2.807-0.723C14.89,12.825,15.021,12.603,14.963,12.385">
                    </path>
                </svg>&nbsp; Bantuan</a>


            <a href="<?php echo site_url('guest/about'); ?>">
                <svg class="svg-iconh" viewBox="0 0 20 20">
                    <path d="M10,2.172c-4.324,0-7.828,3.504-7.828,7.828S5.676,17.828,10,17.828c4.324,0,7.828-3.504,7.828-7.828S14.324,2.172,10,2.172M10,17.004c-3.863,0-7.004-3.141-7.004-7.003S6.137,2.997,10,2.997c3.862,0,7.004,3.141,7.004,7.004S13.862,17.004,10,17.004M10,8.559c-0.795,0-1.442,0.646-1.442,1.442S9.205,11.443,10,11.443s1.441-0.647,1.441-1.443S10.795,8.559,10,8.559 M10,10.619c-0.34,0-0.618-0.278-0.618-0.618S9.66,9.382,10,9.382S10.618,9.661,10.618,10S10.34,10.619,10,10.619 M14.12,8.559c-0.795,0-1.442,0.646-1.442,1.442s0.647,1.443,1.442,1.443s1.442-0.647,1.442-1.443S14.915,8.559,14.12,8.559 M14.12,10.619c-0.34,0-0.618-0.278-0.618-0.618s0.278-0.618,0.618-0.618S14.738,9.661,14.738,10S14.46,10.619,14.12,10.619 M5.88,8.559c-0.795,0-1.442,0.646-1.442,1.442s0.646,1.443,1.442,1.443S7.322,10.796,7.322,10S6.675,8.559,5.88,8.559 M5.88,10.619c-0.34,0-0.618-0.278-0.618-0.618S5.54,9.382,5.88,9.382S6.498,9.661,6.498,10S6.22,10.619,5.88,10.619">
                    </path>
                </svg>&nbsp; Tentang Kami</a>

            &nbsp;
        <div class="underline"></div>

            <a href="http://www.diskominfo.sukoharjokab.go.id/" target="_blank">
                <svg class="svg-iconi" viewBox="0 0 20 20">
                    <path fill="none" d="M10,2.531c-4.125,0-7.469,3.344-7.469,7.469c0,4.125,3.344,7.469,7.469,7.469c4.125,0,7.469-3.344,7.469-7.469C17.469,5.875,14.125,2.531,10,2.531 M10,3.776c1.48,0,2.84,0.519,3.908,1.384c-1.009,0.811-2.111,1.512-3.298,2.066C9.914,6.072,9.077,5.017,8.14,4.059C8.728,3.876,9.352,3.776,10,3.776 M6.903,4.606c0.962,0.93,1.82,1.969,2.53,3.112C7.707,8.364,5.849,8.734,3.902,8.75C4.264,6.976,5.382,5.481,6.903,4.606 M3.776,10c2.219,0,4.338-0.418,6.29-1.175c0.209,0.404,0.405,0.813,0.579,1.236c-2.147,0.805-3.953,2.294-5.177,4.195C4.421,13.143,3.776,11.648,3.776,10 M10,16.224c-1.337,0-2.572-0.426-3.586-1.143c1.079-1.748,2.709-3.119,4.659-3.853c0.483,1.488,0.755,3.071,0.784,4.714C11.271,16.125,10.646,16.224,10,16.224 M13.075,15.407c-0.072-1.577-0.342-3.103-0.806-4.542c0.673-0.154,1.369-0.243,2.087-0.243c0.621,0,1.22,0.085,1.807,0.203C15.902,12.791,14.728,14.465,13.075,15.407 M14.356,9.378c-0.868,0-1.708,0.116-2.515,0.313c-0.188-0.464-0.396-0.917-0.621-1.359c1.294-0.612,2.492-1.387,3.587-2.284c0.798,0.97,1.302,2.187,1.395,3.517C15.602,9.455,14.99,9.378,14.356,9.378">
                    </path>
                </svg>&nbsp; KOMINFO SKH</a>

            <p>DISKOMINFO SUKOHRJO <br> Jl. Kyai Mawardi No.1 Sukoharjo <br> Telp. (0271) 593068 ext. (147)</p>
        
        </div>

    <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span> 
        &nbsp;
        &nbsp;
    <!-- END SIDEBAROVERLY -->

    <a href="<?php echo site_url('guest/');?>"><img src="<?php echo base_url();?>assets/img/new.png" width="45%" height="17%"/></a>


    <!--BUTTON LOGIN ADMIN-->
    <button onclick="document.getElementById('id01').style.display='block'" style="width:auto;" >
        <svg class="svg-icon" viewBox="0 0 18 18">
            <path d="M12.075,10.812c1.358-0.853,2.242-2.507,2.242-4.037c0-2.181-1.795-4.618-4.198-4.618S5.921,4.594,5.921,6.775c0,1.53,0.884,3.185,2.242,4.037c-3.222,0.865-5.6,3.807-5.6,7.298c0,0.23,0.189,0.42,0.42,0.42h14.273c0.23,0,0.42-0.189,0.42-0.42C17.676,14.619,15.297,11.677,12.075,10.812 M6.761,6.775c0-2.162,1.773-3.778,3.358-3.778s3.359,1.616,3.359,3.778c0,2.162-1.774,3.778-3.359,3.778S6.761,8.937,6.761,6.775 M3.415,17.69c0.218-3.51,3.142-6.297,6.704-6.297c3.562,0,6.486,2.787,6.705,6.297H3.415z"></path>
        </svg>&nbsp; Sign In
    </button>

    <!--END BUTTON LOGIN ADMIN-->

    <!-- CSS POP -->
    <div id="id01" class="modal">
        <form class="modal-content animate" action="<?php echo site_url('login/submit'); ?>" method="post">

            <div class="imgcontainer">
                <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Login">&times;</span>
            </div>

            <div id="card">
                <div id="card-content">
                    <div id="card-title">LOGIN</div>
                    <div class="underline-title"></div>

                    <h5>&nbsp;</h5>

                    <label for="user-name" style="padding-top:13px">
                        &nbsp;Username
                    </label>

                    <input class="form-content" type="name" name="username" required />

                    <div class="form-border"></div>

                    <label for="user-password" style="padding-top:13px" >
                        &nbsp;Password
                    </label>

                    <input class="form-content" type="password" name="password" required />

                    <div class="form-border"></div>

                    <input id="submit-btn" type="submit" name="submit" value="LOGIN" />
                </div>
            </div>
        </form>
    </div>
    
</div>