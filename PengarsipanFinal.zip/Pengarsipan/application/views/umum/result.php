
<div class="w3-container">   

  <!--CONTENT-->
  <?php
  
  echo form_open_multipart('guest/search'); 

  $love = array(
        'width'       => 800,
        'height'      => 150,
        'scrollbars'  => 'yes',
        'status'      => 'yes',
        'resizable'   => 'yes',
        'screenx'     => 280,
        'screeny'     => 250,
        'window_name' => '_blank'
  );
  ?>

    <!--TITLE-->
    <div class="w3-col" align="center">
      <h2 style="padding-left:0">SEARCH</h2>
    </div>
    <!--END TITLE-->

    <div class="w3-third" align="center">&nbsp;</div>

    <div class="w3-third" align="center">
      <div class="col-sm-10" align="center">
        <input id="submit-btna" type="textarea" class="form-control" name="key" placeholder="Pencarian">
      </div>
    </div>

    <div class="w3-third" align="center">&nbsp;</div>
    <div class="w3-third" align="center">&nbsp;</div>
    <div class="w3-third" align="center">&nbsp;</div>
    <div class="w3-third" align="center">&nbsp;</div>

    <div class="w3-third" align="center">
    </div>

    <div class="w3-third">&nbsp;</div>

  <!--END CONTENT-->
  
  <!-- DAFTAR ADMIN -->

    <!--TITLE-->
    <div class="w3-col" align="center">
      <h2 style="padding-left:0">HASIL PENCARIAN</h2>
      <h5 style="padding-right:0" align="right"><?php echo "Total Arsip Keseluruhan : ".$totalArsip; ?></h5>
    </div>
    <!--END TITLE-->
    <div class="w3-col">
      &nbsp;
      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th>Nomor</th>
              <th>Kategori</th>
              <th>Status</th>
              <th width="150px">Organisasi Perangkat Daerah</th>
              <th>Lokasi</th>
              <th width="200px">Judul</th>
              <th>Tahun</th>
              <th>Tanggal Masuk</th>
              <th>Keterangan</th>
            </tr>
          </thead>
          <tbody>
            <?php 
            // menampilkan data buku
            foreach ($book as $book_item): 
            ?>
            <tr>
              <td><?php echo $book_item['nomor']?></td>
              <td><?php echo $book_item['idkategori']?></td>

              <td width="120px"><?php if ($book_item['status'] == 'Tersedia'){echo "<font color='#007AFF'>".$book_item['status'];} else {echo "<font color='red'>".anchor_popup('guest/detailpinjam/'.$book_item['nomor'], $book_item['status'], $love); echo anchor_popup('guest/detailpinjam/'.$book_item['nomor'], "&nbsp; <svg class='svg-icona' viewBox='0 0 20 20'>
                <path fill='none' d='M19.175,4.856L15.138,0.82c-0.295-0.295-0.817-0.295-1.112,0L8.748,6.098c-0.307,0.307-0.307,0.805,0,1.112l1.462,1.462l-1.533,1.535L7.215,8.746c-0.307-0.307-0.805-0.307-1.112,0l-5.278,5.276c-0.307,0.307-0.307,0.805,0,1.112l4.037,4.037c0.154,0.153,0.355,0.23,0.556,0.23c0.201,0,0.403-0.077,0.556-0.23l5.28-5.276c0.148-0.148,0.23-0.347,0.23-0.556c0-0.209-0.083-0.409-0.23-0.556l-1.464-1.464l1.533-1.535l1.462,1.462c0.153,0.153,0.355,0.23,0.556,0.23c0.201,0,0.402-0.077,0.556-0.23l5.278-5.278c0.147-0.147,0.23-0.347,0.23-0.556C19.406,5.203,19.322,5.004,19.175,4.856zM9.585,13.339l-4.167,4.164l-2.925-2.925l4.166-4.164l0.906,0.905l-0.67,0.668c-0.307,0.307-0.307,0.805,0,1.112c0.154,0.153,0.356,0.23,0.556,0.23c0.203,0,0.403-0.077,0.556-0.23l0.67-0.668L9.585,13.339z M13.341,9.578l-0.906-0.906l0.663-0.662c0.307-0.307,0.307-0.805,0-1.112c-0.307-0.307-0.805-0.307-1.112,0L11.322,7.56l-0.906-0.906l4.166-4.166l2.925,2.925L13.341,9.578z'></path>
                </svg>", $love);}?></td>

              <td><?php echo $book_item['departemen']?></td>
              <td width="170px"><?php echo $book_item['lokasi']?></td>
              
              <td><b><?php if ($book_item['idkategori'] == 'Surat'){echo "<font color='#007AFF'>".anchor_popup('guest/detailsurat/'.$book_item['nomor'], $book_item['judul'], $love); echo anchor_popup('guest/detailsurat/'.$book_item['nomor'], "&nbsp; <svg class='svg-iconb' viewBox='0 0 20 20'>
                <path fill='none' d='M19.175,4.856L15.138,0.82c-0.295-0.295-0.817-0.295-1.112,0L8.748,6.098c-0.307,0.307-0.307,0.805,0,1.112l1.462,1.462l-1.533,1.535L7.215,8.746c-0.307-0.307-0.805-0.307-1.112,0l-5.278,5.276c-0.307,0.307-0.307,0.805,0,1.112l4.037,4.037c0.154,0.153,0.355,0.23,0.556,0.23c0.201,0,0.403-0.077,0.556-0.23l5.28-5.276c0.148-0.148,0.23-0.347,0.23-0.556c0-0.209-0.083-0.409-0.23-0.556l-1.464-1.464l1.533-1.535l1.462,1.462c0.153,0.153,0.355,0.23,0.556,0.23c0.201,0,0.402-0.077,0.556-0.23l5.278-5.278c0.147-0.147,0.23-0.347,0.23-0.556C19.406,5.203,19.322,5.004,19.175,4.856zM9.585,13.339l-4.167,4.164l-2.925-2.925l4.166-4.164l0.906,0.905l-0.67,0.668c-0.307,0.307-0.307,0.805,0,1.112c0.154,0.153,0.356,0.23,0.556,0.23c0.203,0,0.403-0.077,0.556-0.23l0.67-0.668L9.585,13.339z M13.341,9.578l-0.906-0.906l0.663-0.662c0.307-0.307,0.307-0.805,0-1.112c-0.307-0.307-0.805-0.307-1.112,0L11.322,7.56l-0.906-0.906l4.166-4.166l2.925,2.925L13.341,9.578z'></path>
                </svg>", $love);} else {echo "<font color='black'> ".$book_item['judul'];}?></b></td>
              
              <td><?php echo $book_item['thn']?></td>
              <td><?php echo $book_item['tglmasuk']?></td>
              <td width="150px"><?php echo $book_item['keterangan']?></td>
            </tr>
            <?php 
            endforeach;
            ?>
          </tbody>
        </table>
      </div>
    </div>

<!-- END DAFTAR ADMIN -->

</div>

</body>
</html>