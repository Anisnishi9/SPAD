
<div class="w3-container">   

  <?php
      // arahkan form submit ke kontroller 'book/insert' 
  echo form_open_multipart('arsipadmin/insertsurat'); 
  ?>

  <style type="text/css">
    select {text-align-last: center;}
  </style>

  <!--TITLE-->
  <div class="w3-col" align="center">
    <h2>TAMBAH ARSIP SURAT</h2> 
  </div>
  <!--END TITLE-->

  <!--CONTENT-->
  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <h7 align="center">Kategori</h7> 
  </div>

  <div class="w3-twothird">
    <div class="col-sm-10" align="center">
      <select id="submit-btna" class="form-control" name="idkategori">  
        <?php
        // menampilkan combo box berisi kategori buku
        foreach ($kategori as $kat_item):
        ?>
        <?php $al = $kat_item['kategori'];
          echo "<option value='$al'"; if ($kat_item['kategori'] == "Surat"){echo 'selected';} echo ">$al</option>";
        ?>
        <?php
        endforeach;
        ?>
      </select>
    </div>
  </div>  
  
  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <h7 align="center">Nomor Arsip</h7> 
  </div>

  <div class="w3-twothird" align="center">

    <div class="w3-five">
      <label for="kode"></label>
      <select id="submit-btna" class="form-control" name="kode">
        <option value="BK">BK</option>
        <option value="DK">DK</option>
        <option value="L">L</option>
        <option value="LP">LP</option>
        <option value="SU" selected>SU</option>
      <select>
    </div>
        
    <div class="w3-five">
      <label for="lantai"></label>
      <select id="submit-btna" class="form-control" name="lantai" >
        <?php if ($role == "PPID"){ echo '<option value="1">1</option>';}
        else if ($role == "JDIH"){ echo '<option value="1">1</option>';}
        else if ($role == "Badan Perncanaan, Penelitian dan Pengembangan Daerah"){ echo '<option value="2">2</option>';}
        else if ($role == "Dinas Perdagangan, Koperasi, Usaha Kecil dan Menengah"){ echo '<option value="2">2</option>';}
        else if ($role == "Dinas Kearsipan dan Perpustakaan"){echo '<option value="3">3</option>';}
        else if ($role == "Dinas Pemberdayaan Masyarakat dan Desa" ){echo '<option value="3">3</option>';}
        else if ($role == "Dinas PPKB & P3A"){echo '<option value="3">3</option>';}
        else if ($role == "Dinas Lingkungan Hidup"){echo '<option value="4">4</option>';}
        else if ($role == "Dinas Perindustrian dan Tenaga Kerja"){echo '<option value="4">4</option>';}
        else if ($role == "Dinas Komunikasi dan Informatika"){ echo '<option value="5">5</option>';}
        else if ($role == "Dinas Pangan"){ echo '<option value="5">5</option>';}
        else if ($role == "Kantor Kesbangpol"){ echo '<option value="5">5</option>';}
        else if ($role == "Dinas Perumahan dan Kawasan Pemukiman"){ echo '<option value="6">6</option>';}
        else if ($role == "Satpol PP"){ echo '<option value="6">6</option>';}
        else if ($role == "Badan Kepegawaian, Pendidikan dan Pelatihan"){ echo '<option value="7">7</option>';}
        else if ($role == "Dinas Kepemudaan dan Olahraga"){ echo '<option value="7">7</option>';}
        else if ($role == "Inspektorat"){ echo '<option value="7">7</option>';}
        else if ($role == "Sekertariat Daerah"){ echo '<option value="8">8</option>';}
        else { echo '<option value="9">9</option>';}
        ?>
      </select>
    </div>           

    <div class="w3-five">
      <label for="lemari"></label>
      <input id="submit-btna" type="text" class="form-control" name="lemari" placeholder="Lemari">
    </div>

    <div class="w3-five">
      <label for="rak"></label>
      <input id="submit-btna" type="text" class="form-control" name="rak" placeholder="Rak">
    </div>

    <div class="w3-five">
      <label for="urut"></label>
      <input id="submit-btna" type="text" class="form-control" name="urut" placeholder="Urut">
    </div>

  </div>


  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <label for="departemen">OPD</h7> 
    </div>

  <div class="w3-twothird" style="padding-bottom:10px">
    <select id="submit-btna" class="form-control" name="departemen">
      <?php if ($role == "JDIH"){ echo '<option value="JDIH">Lantai 1 - JDIH</option>';}
      else if ($role == "PPID"){ echo '<option value="PPID">Lantai 1 - PPID</option>';}
      else if ($role == "Badan Perncanaan, Penelitian dan Pengembangan Daerah"){ echo '<option value="Badan Perncanaan, Penelitian dan Pengembangan Daerah">Lantai 2 - Badan Perncanaan, Penelitian dan Pengembangan Daerah</option>';}
      else if ($role == "Dinas Perdagangan, Koperasi, Usaha Kecil dan Menengah"){ echo '<option value="Dinas Perdagangan, Koperasi, Usaha Kecil dan Menengah">Lantai 2 - Dinas Perdagangan, Koperasi, Usaha Kecil dan Menengah</option>';}
      else if ($role == "Dinas Kearsipan dan Perpustakaan"){ echo '<option value="Dinas Kearsipan dan Perpustakaan">Lantai 3 - Dinas Kearsipan dan Perpustakaan</option>';}
      else if ($role == "Dinas Pemberdayaan Masyarakat dan Desa"){ echo '<option value="Dinas Pemberdayaan Masyarakat dan Desa">Lantai 3 - Dinas Pemberdayaan Masyarakat dan Desa</option>';}
      else if ($role == "Dinas PPKB & P3A"){ echo '<option value="Dinas PPKB & P3A">Lantai 3 - Dinas PPKB & P3A</option>';}
      else if ($role == "Dinas Lingkungan Hidup"){ echo '<option value="Dinas Lingkungan Hidup">Lantai 4 - Dinas Lingkungan Hidup</option>';}
      else if ($role == "Dinas Perindustrian dan Tenaga Kerja"){ echo '<option value="Dinas Perindustrian dan Tenaga Kerja">Lantai 4 - Dinas Perindustrian dan Tenaga Kerja</option>';}
      else if ($role == "Dinas Komunikasi dan Informatika"){ echo '<option value="Dinas Komunikasi dan Informatika">Lantai 5 - Dinas Komunikasi dan Informatika</option>';}
      else if ($role == "Dinas Pangan"){ echo '<option value="Dinas Pangan">Lantai 5 - Dinas Pangan</option>';}
      else if ($role == "Kantor Kesbangpol"){ echo '<option value="Kantor Kesbangpol">Lantai 5 - Kantor Kesbangpol</option>';}
      else if ($role == "Dinas Perumahan dan Kawasan Pemukiman"){ echo '<option value="Dinas Perumahan dan Kawasan Pemukiman">Lantai 6 - Dinas Perumahan dan Kawasan Pemukiman</option>';}
      else if ($role == "Satpol PP"){ echo '<option value="Satpol PP">Lantai 6 - Satpol PP</option>';}
      else if ($role == "Badan Kepegawaian, Pendidikan dan Pelatihan"){ echo '<option value="Badan Kepegawaian, Pendidikan dan Pelatihan">Lantai 7 - Badan Kepegawaian, Pendidikan dan Pelatihan</option>';}
      else if ($role == "Dinas Kepemudaan dan Olahraga"){ echo '<option value="Dinas Kepemudaan dan Olahraga">Lantai 7 - Dinas Kepemudaan dan Olahraga</option>';}
      else if ($role == "Inspektorat"){ echo '<option value="Inspektorat">Lantai 7 - Inspektorat</option>';}
      else if ($role == "Sekertariat Daerah"){ echo '<option value="Sekertariat Daerah">Lantai 8 - Sekertariat Daerah</option>';}
      else { echo '<option value="Sekertaris Daerah">Lantai 9 - Sekertaris Daerah</option>';}?>
    <select>
  </div> 

  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <label for="klasifikasi">Klasifikasi</h7> 
  </div>

  <div class="w3-twothird" style="padding-bottom:10px">
    <select id="submit-btna" class="form-control" name="klasifikasi">
      <option value="Klasifikasi">Klasifikasi</option>
      <option value="Surat Masuk">Surat Masuk</option>
      <option value="Surat Keluar">Surat Keluar</option>
    <select>
  </div>  

  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <label for="jenis">Jenis Surat</label>
  </div>

  <div class="w3-twothird" style="padding-bottom:10px">
      <select id="submit-btna" class="form-control" name="jenis">
        <option value="Jenis Surat">Jenis Surat</option>
        <option value="Surat Permohonan">Surat Permohonan</option>
        <option value="Surat Keputusan">Surat Keputusan</option>
        <option value="Surat Kuasa">Surat Kuasa</option>
        <option value="Surat Perintah">Surat Perintah</option>
        <option value="Surat Pengantar">Surat Pengantar</option>
        <option value="Surat Edaran">Surat Edaran</option>
        <option value="Surat Undangan">Surat Undangan</option>
    <select>
  </div>

  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <label for="nomorsurat">Nomor Surat</label>
  </div>

  <div class="w3-twothird" style="padding-bottom:10px">
    <input id="submit-btna" type="text" class="form-control" name="nomorsurat" placeholder="Masukkan Nomor Surat" style="float:left">
  </div>

  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <label for="dari">Pengirim</label>
  </div>

  <div class="w3-twothird" style="padding-bottom:10px">
    <input id="submit-btna" type="text" class="form-control" name="dari" placeholder="Masukkan Pengirim" style="float:left">
  </div>

  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <label for="kepada">Diteruskan</label>
  </div>

  <div class="w3-twothird" style="padding-bottom:10px">
    <input id="submit-btna" type="text" class="form-control" name="kepada" placeholder="Masukkan Penerima Tujuan" style="float:left">
  </div>

  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <label for="judul">Perihal / Judul</label>
  </div>

  <div class="w3-twothird" style="padding-bottom:10px">
    <input id="submit-btna" type="text" class="form-control" name="judul" placeholder="Masukkan Perihal / Judul Surat" style="float:left">
  </div>

  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <label for="lampiran">Lampiran</label>
  </div>

  <div class="w3-twothird" style="padding-bottom:10px">
    <input id="submit-btna" type="text" class="form-control" name="lampiran" placeholder="Masukkan Lampiran Surat" style="float:left">
  </div>

  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <label for="thn">Tahun Surat</label>
  </div>

  <div class="w3-twothird" style="padding-bottom:10px">
    <select id="submit-btna" style="float:left" class="form-control" name="thn">
      <option value="Tahun">Tahun</option>
      <?php $awal = date(' Y')-10;
              $akhir = date(' Y')+5;
              for ($i=$akhir; $i>=$awal; $i--){
                echo "<option value='$i'"; if (date('Y') == $i){echo 'selected';} echo ">$i</option>";}?>
    </select>
  </div>

  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 20px" >
    <h7 align="center">Tanggal Surat</h7>  
  </div>

  <div class="w3-twothird">

    <div class="w3-five">
      <label for="hari"></label>
      <select id="submit-btna" style="float:left" class="form-control" name="hari">
        <option value="Hari">Hari</option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
        <option value="6">6</option>
        <option value="7">7</option>
        <option value="8">8</option>
        <option value="9">9</option>
        <option value="10">10</option>
        <option value="11">11</option>
        <option value="12">12</option>
        <option value="13">13</option>
        <option value="14">14</option>
        <option value="15">15</option>
        <option value="16">16</option>
        <option value="17">17</option>
        <option value="18">18</option>
        <option value="19">19</option>
        <option value="20">20</option>
        <option value="21">21</option>
        <option value="22">22</option>
        <option value="23">23</option>
        <option value="24">24</option>
        <option value="25">25</option>
        <option value="26">26</option>
        <option value="27">27</option>
        <option value="28">28</option>
        <option value="29">29</option>
        <option value="30">30</option>
        <option value="31">31</option>
      </select>
    </div>

    <div class="w3-five">
      <label for="bulan"></label>
      <select id="submit-btna" style="float:left" class="form-control" name="bulan">
        <option value=" Bulan ">Bulan</option>
        <option value=" Januari ">Januari</option>
        <option value=" Februari ">Februari</option>
        <option value=" Maret ">Maret</option>
        <option value=" April ">April</option>
        <option value=" Mei ">Mei</option>
        <option value=" Juni ">Juni</option>
        <option value=" Juli ">Juli</option>
        <option value=" Agustus ">Agustus</option>
        <option value=" September ">September</option>
        <option value=" Oktober ">Oktober</option>
        <option value=" November ">November</option>
        <option value=" Desember ">Desember</option>
      </select>
    </div>

    <div class="w3-five">
      <label for="tahun"></label>
      <select id="submit-btna" style="float:left" class="form-control" name="tahun">
        <option value="Tahun">Tahun</option>
                <?php $awal = date(' Y')-10;
              $akhir = date(' Y')+5;
              for ($i=$akhir; $i>=$awal; $i--){
                echo "<option value='$i'"; if (date(' Y') == $i){echo 'selected';} echo ">$i</option>";}?>
      </select>
    </div>

  </div>

  <div class="w3-third">&nbsp;</div>

  <div class="w3-third">
    <div class="w3-third" align="center">
      <form action="#"   >
        <button id="submit-btna" style="display: inline">Tambah Arsip</button>
      </form>
    </div>  
    <div class="w3-third">&nbsp;</div>
    <div class="w3-third">&nbsp;</div>
  </div>

  <!--END CONTENT-->

</div>

</body>
</html>