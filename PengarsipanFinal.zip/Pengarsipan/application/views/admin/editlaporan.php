
<div class="w3-container">   

  <?php
  // arahkan form submit ke kontroller 'book/insert' 
  echo form_open_multipart('arsipadmin/ulap'); 
  ?>
  
  <style type="text/css">
    select {text-align-last: center;}
  </style>

  <!--TITLE-->
  <div class="w3-col" align="center">
    <h2>EDIT ARSIP LAPORAN</h2> 
  </div>
  <!--END TITLE-->

  <!--CONTENT-->

  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <h7 align="center">Nomor Arsip</h7> 
  </div>

  <div class="w3-twothird" style="padding-bottom:10px">
    <input id="submit-btna" type="text" class="form-control" name="nomor" value="<?php echo $nomor; ?>">
  </div>

  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <h7 align="center">Lokasi Arsip</h7> 
  </div>

  <div class="w3-twothird" style="padding-bottom:10px">
    <input id="submit-btna" type="text" class="form-control" name="lokasi" value="<?php echo $lokasi; ?>">
  </div>

  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <label for="departemen">OPD</h7> 
  </div>

  <div class="w3-twothird" style="padding-bottom:10px">
    <select id="submit-btna" class="form-control" name="departemen">
      <?php if ($role == "JDIH"){ echo '<option value="JDIH">Lantai 1 - JDIH</option>';}
      else if ($role == "PPID"){ echo '<option value="PPID">Lantai 1 - PPID</option>';}
      else if ($role == "Badan Perncanaan, Penelitian dan Pengembangan Daerah"){ echo '<option value="Badan Perncanaan, Penelitian dan Pengembangan Daerah">Lantai 2 - Badan Perncanaan, Penelitian dan Pengembangan Daerah</option>';}
      else if ($role == "Dinas Perdagangan, Koperasi, Usaha Kecil dan Menengah"){ echo '<option value="Dinas Perdagangan, Koperasi, Usaha Kecil dan Menengah">Lantai 2 - Dinas Perdagangan, Koperasi, Usaha Kecil dan Menengah</option>';}
      else if ($role == "Dinas Kearsipan dan Perpustakaan"){ echo '<option value="Dinas Kearsipan dan Perpustakaan">Lantai 3 - Dinas Kearsipan dan Perpustakaan</option>';}
      else if ($role == "Dinas Pemberdayaan Masyarakat dan Desa"){ echo '<option value="Dinas Pemberdayaan Masyarakat dan Desa">Lantai 3 - Dinas Pemberdayaan Masyarakat dan Desa</option>';}
      else if ($role == "Dinas PPKB & P3A"){ echo '<option value="Dinas PPKB & P3A">Lantai 3 - Dinas PPKB & P3A</option>';}
      else if ($role == "Dinas Lingkungan Hidup"){ echo '<option value="Dinas Lingkungan Hidup">Lantai 4 - Dinas Lingkungan Hidup</option>';}
      else if ($role == "Dinas Perindustrian dan Tenaga Kerja"){ echo '<option value="Dinas Perindustrian dan Tenaga Kerja">Lantai 4 - Dinas Perindustrian dan Tenaga Kerja</option>';}
      else if ($role == "Dinas Komunikasi dan Informatika"){ echo '<option value="Dinas Komunikasi dan Informatika">Lantai 5 - Dinas Komunikasi dan Informatika</option>';}
      else if ($role == "Dinas Pangan"){ echo '<option value="Dinas Pangan">Lantai 5 - Dinas Pangan</option>';}
      else if ($role == "Kantor Kesbangpol"){ echo '<option value="Kantor Kesbangpol">Lantai 5 - Kantor Kesbangpol</option>';}
      else if ($role == "Dinas Perumahan dan Kawasan Pemukiman"){ echo '<option value="Dinas Perumahan dan Kawasan Pemukiman">Lantai 6 - Dinas Perumahan dan Kawasan Pemukiman</option>';}
      else if ($role == "Satpol PP"){ echo '<option value="Satpol PP">Lantai 6 - Satpol PP</option>';}
      else if ($role == "Badan Kepegawaian, Pendidikan dan Pelatihan"){ echo '<option value="Badan Kepegawaian, Pendidikan dan Pelatihan">Lantai 7 - Badan Kepegawaian, Pendidikan dan Pelatihan</option>';}
      else if ($role == "Dinas Kepemudaan dan Olahraga"){ echo '<option value="Dinas Kepemudaan dan Olahraga">Lantai 7 - Dinas Kepemudaan dan Olahraga</option>';}
      else if ($role == "Inspektorat"){ echo '<option value="Inspektorat">Lantai 7 - Inspektorat</option>';}
      else if ($role == "Sekertariat Daerah"){ echo '<option value="Sekertariat Daerah">Lantai 8 - Sekertariat Daerah</option>';}
      else { echo '<option value="Sekertaris Daerah">Lantai 9 - Sekertaris Daerah</option>';}?>
    <select>
  </div>

  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <label for="judul">Judul Laporan</label>
  </div>

  <div class="w3-twothird" style="padding-bottom:10px">
    <input id="submit-btna" type="text" class="form-control" name="judul" value="<?php echo $judul; ?>">
  </div>

  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <label for="thn">Tahun Laporan</label>
  </div>
  
  <div class="w3-twothird" style="padding-bottom:10px">
    <input id="submit-btna" type="text" class="form-control" name="thn" value="<?php echo $tahun; ?>">
  </div>

  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 20px" >
    <h7 align="center">Tanggal Masuk Laporan</h7>  
  </div>

    <div class="w3-twothird" style="padding-bottom:10px">
    <input id="submit-btna" type="text" class="form-control" name="tglmasuk" value="<?php echo $tglmasuk; ?>">
  </div>

  <div class="w3-third">&nbsp;</div>
  <div class="w3-third">
    <div class="w3-third" align="center">
        <button id="submit-btna" style="display: inline">Update</button>
    </div>    
    <div class="w3-third" align="left">
      <a href="<?php echo site_url('administrator/search'); ?>">
        <button id="submit-btnb" style="display: inline" >Cancel</button></a>
    </div>  
  </div>

  <!--END CONTENT-->

</div>

</body>
</html>