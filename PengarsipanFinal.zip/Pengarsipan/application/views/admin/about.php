
<div class="w3-container">   
    
    <!--TITLE-->
    <div class="w3-col" align="center">
    	<h2 style="padding-left:0">TENTANG KAMI</h2>
    </div>
    <!--END TITLE-->

	<!--CONTENT-->	
	<div class="w3-col" align="center">
		<h4 style="padding-left:0">SISTEM PENYIMPANAN ARSIP PEMERINTAH KABUPATEN SUKOHARJO VERSION 1.0</h4>
		<p style="padding-left:0">Copyright(c) 2020 PTIK FKIP UNS</p>
	</div>
	<!--END CONTENT-->

</div>

</body>
</html>