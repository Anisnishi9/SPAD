
<div class="w3-container">   

	<!--CONTENT-->

	<div class="w3-col" align="center">
		<h2 style="padding-left:0">BANTUAN</h2>

		<h4 style="padding-left:0">PENCARIAN</h4>
		<p style="padding-left:0">Metode pencarian arsip yang tersedia di Sistem Pengarsipan Pemerintah Kabupaten Sukoharjo dapat dilakukan oleh pengguna <br> dengan memasukkan kata kunci apapun, baik itu yang terkandung dalam judul arsip maupun berdasarkan <br> jenis kategori arsip yang hendak dicari lalu tekan enter.</p>

		<h4 style="padding-left:0">RIWAYAT PEMINJAM</h4>
		<p style="padding-left:0">Berisi daftar riwayat peminjam arsip dan hanya dapat dihapus oleh Administrator.</p>

		<h4 style="padding-left:0">TAMBAH ARSIP</h4>
		<p style="padding-left:0">Pada menu tambah arsip ini Administrator dapat menambahkan arsip baru sesuai dengan kategori yang dipilih.</p>
		
		<h4 style="padding-left:0">TAMBAH KATEGORI</h4>
		<p style="padding-left:0">Pada menu tambah kategori ini Administrator dapat menambahkan jenis kategori baru untuk arsip.</p>

	</div>
	<!--END CONTENT-->

</div>

</body>
</html>