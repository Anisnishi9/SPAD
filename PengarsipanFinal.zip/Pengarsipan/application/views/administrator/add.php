
<div class="w3-container">   
	
	<!--TITLE-->
	<div class="w3-col" align="center">
		<h2 style="padding-left: 0">TAMBAH ARSIP</h2> 
	</div>
	<!--END TITLE-->

	<!--CONTENT-->
	<?php
      // arahkan form submit ke kontroller 'book/insert' 
	echo form_open_multipart('administrator/tambah'); 
	?>

	<div class="w3-third">&nbsp;</div>

	<div class="w3-third">
		<div class="col-sm-10" align="center">
			<select id="submit-btna" class="form-control" name="idkategori">  
				<?php
				// menampilkan combo box berisi kategori buku
				foreach ($kategori as $kat_item):
				?>
			<option value="<?php echo $kat_item['idkategori']?>"><?php echo $kat_item['kategori']?></option>
				<?php
				endforeach;
				?>
			</select>
		</div>
	</div>      

	<div class="w3-third">&nbsp;</div>
	<div class="w3-third">&nbsp;</div>
	<div class="w3-third">&nbsp;</div>
	<div class="w3-third">&nbsp;</div>

	<div class="w3-third" align="center">
		<button id="submit-btna" type="textarea" name="judul" style="display: inline">Selanjutnya</button>
	</div>
	<!--END CONTENT-->

</div>

</body>
</html>