
<div class="w3-container">   

  <?php
  // arahkan form submit ke kontroller 'book/insert' 
  echo form_open_multipart('arsip/usurat'); 
  ?>

  <style type="text/css">
    select {text-align-last: center;}
  </style>

  <!--TITLE-->
  <div class="w3-col" align="center">
    <h2>EDIT ARSIP SURAT</h2> 
  </div>
  <!--END TITLE-->

  <!--CONTENT-->
  
  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <h7 align="center">Nomor Arsip</h7> 
  </div>

  <div class="w3-twothird" style="padding-bottom:10px">
    <input id="submit-btna" type="text" class="form-control" name="nomor" value="<?php echo $nomor; ?>">
  </div>

  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <h7 align="center">Lokasi Arsip</h7> 
  </div>

  <div class="w3-twothird" style="padding-bottom:10px">
    <input id="submit-btna" type="text" class="form-control" name="lokasi" value="<?php echo $lokasi; ?>">
  </div>

  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <label for="departemen">OPD</h7> 
  </div>

  <div class="w3-twothird" style="padding-bottom:10px">
    <input id="submit-btna" type="text" class="form-control" name="departemen" value="<?php echo $departemen; ?>">
  </div>

  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <label for="judul">Perihal Surat </label>
  </div>

  <div class="w3-twothird" style="padding-bottom:10px">
    <input id="submit-btna" type="text" class="form-control" name="judul" value="<?php echo $judul; ?>">
  </div>

  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <label for="klasifikasi">Klasifikasi</label>
  </div>

  <div class="w3-twothird" style="padding-bottom:10px">
    <input id="submit-btna" type="text" class="form-control" name="klasifikasi" value="<?php echo $klasifikasi; ?>">
  </div>

  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <label for="jenis">Jenis Surat</label>
  </div>

  <div class="w3-twothird" style="padding-bottom:10px">
    <input id="submit-btna" type="text" class="form-control" name="jenis" value="<?php echo $jenis; ?>">
  </div>
  
  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <label for="nomorsurat">Nomor Surat</label>
  </div>

  <div class="w3-twothird" style="padding-bottom:10px">
    <input id="submit-btna" type="text" class="form-control" name="nomorsurat" value="<?php echo $nomorsurat; ?>">
  </div>

    <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <label for="dari">Instansi Pengirim</label>
  </div>

  <div class="w3-twothird" style="padding-bottom:10px">
    <input id="submit-btna" type="text" class="form-control" name="dari" value="<?php echo $dari; ?>">
  </div>

  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <label for="kepada">Diteruskan Kepada</label>
  </div>

  <div class="w3-twothird" style="padding-bottom:10px">
    <input id="submit-btna" type="text" class="form-control" name="kepada" value="<?php echo $kepada; ?>">
  </div>

  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <label for="lampiran">Lampiran</label>
  </div>

  <div class="w3-twothird" style="padding-bottom:10px">
    <input id="submit-btna" type="text" class="form-control" name="lampiran" value="<?php echo $lampiran; ?>">
  </div>

  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <label for="thn">Tahun Surat</label>
  </div>
  
  <div class="w3-twothird" style="padding-bottom:10px">
    <input id="submit-btna" type="text" class="form-control" name="thn" value="<?php echo $tahun; ?>">
  </div>

  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 20px" >
    <h7 align="center">Tanggal Masuk Surat</h7>  
  </div>

  <div class="w3-twothird" style="padding-bottom:10px">
    <input id="submit-btna" type="text" class="form-control" name="tglmasuk" value="<?php echo $tglmasuk; ?>">
  </div>

  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 20px" >
    <h7 align="center">Tanggal Surat</h7>  
  </div>

  <div class="w3-twothird" style="padding-bottom:10px">
    <input id="submit-btna" type="text" class="form-control" name="tglsurat" value="<?php echo $tglsurat; ?>">
  </div>

  <div class="w3-third">&nbsp;</div>
  <div class="w3-third">
    <div class="w3-third" align="center">
        <button id="submit-btna" style="display: inline">Update</button>
    </div>    
    <div class="w3-third" align="left">
      <a href="<?php echo site_url('administrator/search'); ?>">
        <button id="submit-btnb" style="display: inline" >Cancel</button></a>
    </div>  
  </div>

  <!--END CONTENT-->

</div>

</body>
</html>