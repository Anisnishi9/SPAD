
<div class="w3-container">   

  <!--CONTENT-->
  <?php
  
  echo form_open_multipart('administrator/cari'); 
  ?>

    <!--TITLE-->
    <div class="w3-col" align="center">
      <h2 style="padding-left:0">SEARCH</h2>
    </div>
    <!--END TITLE-->

    <div class="w3-third" align="center">&nbsp;</div>

    <div class="w3-third" align="center">
      <div class="col-sm-10" align="center">
        <input id="submit-btna" type="textarea" class="form-control" name="law" placeholder="Pencarian">
      </div>
    </div>

    <div class="w3-third" align="center">&nbsp;</div>
    <div class="w3-third" align="center">&nbsp;</div>
    <div class="w3-third" align="center">&nbsp;</div>
    <div class="w3-third" align="center">&nbsp;</div>

    <div class="w3-third" align="center">
    </div>

    <div class="w3-third">&nbsp;</div>

  <!--END CONTENT-->
  
  <!-- DAFTAR ADMIN -->

    <!--TITLE-->
    <div class="w3-col" align="center">
      <h2 style="padding-left:0">HASIL PENCARIAN</h2>
    </div>
    <!--END TITLE-->
    <div class="w3-col">
      &nbsp;
      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th>Nomor Arsip</th>
              <th width="250px">Institusi / Perangkat Daerah</th>
              <th>Nama Peminjam</th>
              <th>NIP Peminjam</th>
              <th>Kontak</th>
              <th>Tanggal Pinjam</th>
              <th>Tanggal Kembali</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php 
            // menampilkan data buku
            foreach ($view as $book_item): 
            ?>
            <tr>
              <td><?php echo $book_item['nomorarsip']?></td>
              <td><?php echo $book_item['departemen']?></td>
              <td><?php echo $book_item['namapeminjam']?></td>
              <td><?php echo $book_item['nippeminjam']?></td>
              <td><?php echo $book_item['kontak']?></td>
              <td><?php echo $book_item['tglpinjam']?></td>
              <td><?php echo $book_item['tglkembali']?></td>
              
              <td><?php echo anchor('administrator/deleteh/'.$book_item['nomorarsip'], '<svg height="25px" viewBox="-48 0 400 400" width="25px" xmlns="http://www.w3.org/2000/svg" fill="red"><path d="m89.199219 37c0-12.132812 9.46875-21 21.601562-21h88.800781c12.128907 0 21.597657 8.867188 21.597657 21v23h16v-23c0-20.953125-16.644531-37-37.597657-37h-88.800781c-20.953125 0-37.601562 16.046875-37.601562 37v23h16zm0 0"/><path d="m60.601562 407h189.199219c18.242188 0 32.398438-16.046875 32.398438-36v-247h-254v247c0 19.953125 14.15625 36 32.402343 36zm145.597657-244.800781c0-4.417969 3.582031-8 8-8s8 3.582031 8 8v189c0 4.417969-3.582031 8-8 8s-8-3.582031-8-8zm-59 0c0-4.417969 3.582031-8 8-8s8 3.582031 8 8v189c0 4.417969-3.582031 8-8 8s-8-3.582031-8-8zm-59 0c0-4.417969 3.582031-8 8-8s8 3.582031 8 8v189c0 4.417969-3.582031 8-8 8s-8-3.582031-8-8zm0 0"/><path d="m20 108h270.398438c11.046874 0 20-8.953125 20-20s-8.953126-20-20-20h-270.398438c-11.046875 0-20 8.953125-20 20s8.953125 20 20 20zm0 0"/></svg>');?></td>
            </tr>
            <?php 
            endforeach;
            ?>
          </tbody>
        </table>
      </div>
    </div>

<!-- END DAFTAR ADMIN -->

</div>

</body>
</html>