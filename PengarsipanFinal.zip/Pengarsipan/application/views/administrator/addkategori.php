
<div class="w3-container">   

  <!--CONTENT-->
  <?php
      // arahkan form submit ke kontroller 'book/insert' 
  echo form_open_multipart('kategori/inserta'); 
  ?>

  <div class="w3-half">

    <!--TITLE-->
    <div class="w3-col" align="center">
      <h2 style="padding-left:0">TAMBAH KATEGORI ARSIP</h2>
    </div>
    <!--END TITLE-->

    <div class="w3-third" align="center">&nbsp;</div>

    <div class="w3-third" >
      <div class="form-group row" align="center">
        <div class="col-sm-10" align="center">
          <input id="submit-btna" type="textarea" class="form-control" name="kate" placeholder="Tambahkan Kategori Baru">
        </div>
      </div>
    </div>

    <div class="w3-third" align="center">&nbsp;</div>
    <div class="w3-third" align="center">&nbsp;</div>
    <div class="w3-third" align="center">&nbsp;</div>
    <div class="w3-third" align="center">&nbsp;</div>


    <div class="w3-third" align="center">
      <form action="#"   >
        <button id="submit-btna" type="textarea" name="judul" style="display: inline">Submit</button>
      </form>
    </div>
    
    <div class="w3-third">&nbsp;</div>
  
  </div>
  <!--END CONTENT-->
  
  <!-- DAFTAR ADMIN -->
  <div class="w3-half">

    <!--TITLE-->
    <div class="w3-col" align="left">
      <h2 style="padding-left:0">DAFTAR KATEGORI ARSIP</h2>
    </div>
    <!--END TITLE-->

    <div class="w3-col">
      &nbsp;
      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th>Nama Kategori</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php
            // menampilkan combo box berisi kategori buku
            foreach ($kategori as $kat_item):
            ?>
              <td><?php echo $kat_item['kategori']?></td>
              <td><font color="red"><?php echo anchor('kategori/deletea/'.$kat_item['idkategori'], '<svg height="25px" viewBox="-48 0 400 400" width="25px" xmlns="http://www.w3.org/2000/svg" fill="red"><path d="m89.199219 37c0-12.132812 9.46875-21 21.601562-21h88.800781c12.128907 0 21.597657 8.867188 21.597657 21v23h16v-23c0-20.953125-16.644531-37-37.597657-37h-88.800781c-20.953125 0-37.601562 16.046875-37.601562 37v23h16zm0 0"/><path d="m60.601562 407h189.199219c18.242188 0 32.398438-16.046875 32.398438-36v-247h-254v247c0 19.953125 14.15625 36 32.402343 36zm145.597657-244.800781c0-4.417969 3.582031-8 8-8s8 3.582031 8 8v189c0 4.417969-3.582031 8-8 8s-8-3.582031-8-8zm-59 0c0-4.417969 3.582031-8 8-8s8 3.582031 8 8v189c0 4.417969-3.582031 8-8 8s-8-3.582031-8-8zm-59 0c0-4.417969 3.582031-8 8-8s8 3.582031 8 8v189c0 4.417969-3.582031 8-8 8s-8-3.582031-8-8zm0 0"/><path d="m20 108h270.398438c11.046874 0 20-8.953125 20-20s-8.953126-20-20-20h-270.398438c-11.046875 0-20 8.953125-20 20s8.953125 20 20 20zm0 0"/></svg>'); ?></td>
            </tr>
            <?php 
            endforeach;
            ?>
          </tbody>
        </table>
      </div>
    </div>

  </div>
<!-- END DAFTAR ADMIN -->

</div>

</body>
</html>