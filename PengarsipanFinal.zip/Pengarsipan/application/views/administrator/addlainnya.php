
<div class="w3-container">   

  <?php
  // arahkan form submit ke kontroller 'book/insert' 
  echo form_open_multipart('arsip/insertlain'); 
  ?>

  <style type="text/css">
    select {text-align-last: center;}
  </style>

  <!--TITLE-->
  <div class="w3-col" align="center">
    <h2>TAMBAH ARSIP</h2> 
  </div>
  <!--END TITLE-->

  <!--CONTENT-->
  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <h7 align="center">Kategori</h7> 
  </div>

  <div class="w3-twothird">
    <div class="col-sm-10" align="center">
      <select id="submit-btna" class="form-control" name="idkategori">  
        <?php
        // menampilkan combo box berisi kategori buku
        foreach ($kategori as $kat_item):
        ?>
        <?php $al = $kat_item['kategori'];
          echo "<option value='$al'"; if ($kat_item['kategori'] == "Lainnya"){echo 'selected';} echo ">$al</option>";
        ?>
        <?php
        endforeach;
        ?>
      </select>
    </div>
  </div>  
  
  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <h7 align="center">Nomor Arsip</h7> 
  </div>

  <div class="w3-twothird" align="center">

    <div class="w3-five">
      <label for="kode"></label>
      <select id="submit-btna" class="form-control" name="kode">
        <option value="Kode">Kode</option>
        <option value="BK">BK</option>
        <option value="DK">DK</option>
        <option value="L" selected>L</option>
        <option value="LP">LP</option>
        <option value="SU">SU</option>
      <select>
    </div>
        
    <div class="w3-five">
      <label for="lantai"></label>
      <select id="submit-btna" class="form-control" name="lantai" >
        <option value="Lantai">Lantai</option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
        <option value="6">6</option>
        <option value="7">7</option>
        <option value="8">8</option>
        <option value="9">9</option>
        <option value="10">10</option>
      </select>
    </div>           

    <div class="w3-five">
      <label for="lemari"></label>
      <input id="submit-btna" type="text" class="form-control" name="lemari" placeholder="Lemari">
    </div>

    <div class="w3-five">
      <label for="rak"></label>
      <input id="submit-btna" type="text" class="form-control" name="rak" placeholder="Rak">
    </div>

    <div class="w3-five">
      <label for="urut"></label>
      <input id="submit-btna" type="text" class="form-control" name="urut" placeholder="Urut">
    </div>

  </div>


  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <label for="departemen">OPD</h7> 
  </div>

  <div class="w3-twothird" style="padding-bottom:10px">
    <select id="submit-btna" class="form-control" name="departemen">
      <option value="OPD">OPD</option>
      <option value="JDIH">Lantai 1 - JDIH</option>
      <option value="PPID">Lantai 1 - PPID</option>
      <option value="Badan Perncanaan, Penelitian dan Pengembangan Daerah">Lantai 2 - Badan Perncanaan, Penelitian dan Pengembangan Daerah</option>
      <option value="Dinas Perdagangan, Koperasi, Usaha Kecil dan Menengah">Lantai 2 - Dinas Perdagangan, Koperasi, & UKM</option>
      <option value="Dinas Kearsipan dan Perpustakaan">Lantai 3 - Dinas Kearsipan dan Perpustakaan</option>
      <option value="Dinas Pemberdayaan Masyarakat dan Desa">Lantai 3 - Dinas Pemberdayaan Masyarakat dan Desa</option>
      <option value="Dinas PPKB & P3A">Lantai 3 - Dinas PPKB & P3A</option>
      <option value="Dinas Lingkungan Hidup">Lantai 4 - Dinas Lingkungan Hidup</option>
      <option value="Dinas Perindustrian dan Tenaga Kerja">Lantai 4 - Dinas Perindustrian dan Tenaga Kerja</option>
      <option value="Dinas Komunikasi dan Informatika">Lantai 5 - Dinas Komunikasi dan Informatika</option>
      <option value="Dinas Pangan">Lantai 5 - Dinas Pangan</option>
      <option value="Kantor Kesbangpol">Lantai 5 - Kantor Kesbangpol</option>
      <option value="Dinas Perumahan dan Kawasan Pemukiman">Lantai 6 - Dinas Perumahan dan Kawasan Pemukiman</option>
      <option value="Satpol PP">Lantai 6 - Satpol PP</option>
      <option value="Badan Kepegawaian, Pendidikan dan Pelatihan">Lantai 7 - Badan Kepegawaian, Pendidikan dan Pelatihan</option>
      <option value="Dinas Kepemudaan dan Olahraga">Lantai 7 - Dinas Kepemudaan dan Olahraga</option>
      <option value="Inspektorat">Lantai 7 - Inspektorat</option>
      <option value="Sekertariat Daerah">Lantai 8 - Sekertariat Daerah</option>
      <option value="Sekertaris Daerah">Lantai 9 - Sekertaris Daerah</option>
    <select>
  </div>

  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <label for="judul">Judul</label>
  </div>

  <div class="w3-twothird" style="padding-bottom:10px">
    <input id="submit-btna" type="text" class="form-control" name="judul" placeholder="Masukkan Judul" style="float:left" align="left">
  </div>

  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <label for="keterangan">Keterangan</label>
  </div>

  <div class="w3-twothird" style="padding-bottom:10px">
    <input id="submit-btna" type="text" class="form-control" name="keterangan" placeholder="Masukkan Keterangan" style="float:left" align="left">
  </div>

  <div class="w3-third" align="left" style="padding-left:300px; padding-top: 30px" >
    <label for="thn">Tahun</label>
  </div>

  <div class="w3-twothird" style="padding-bottom:10px">
    <select id="submit-btna" style="float:left" class="form-control" name="thn">
      <option value="Tahun">Tahun</option>
      <?php $awal = date(' Y')-10;
              $akhir = date(' Y')+5;
              for ($i=$akhir; $i>=$awal; $i--){
                echo "<option value='$i'"; if (date('Y') == $i){echo 'selected';} echo ">$i</option>";}?>
    </select>
  </div>

  <div class="w3-third">&nbsp;</div>
  <div class="w3-third">
    <div class="w3-third" align="center">
        <button id="submit-btna" style="display: inline">Submit</button>
    </div>     
  </div>

  <!--END CONTENT-->

</div>

</body>
</html>