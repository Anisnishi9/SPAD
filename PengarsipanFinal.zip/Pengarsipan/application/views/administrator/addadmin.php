
<div class="w3-container">   
  
  <?php
// arahkan form submit ke kontroller 'book/insert' 
  echo form_open_multipart('user/insert'); 
  ?>

  <style type="text/css">
    select {text-align-last: center;}
  </style>
  
  <div class="w3-half">

    <!--TITLE-->
    <div class="w3-col" align="center">
      <h2 style="padding-left:0">TAMBAH ADMIN</h2>
    </div>
    <!--END TITLE-->
    
    <!--CONTENT-->
    <div class="w3-third" align="center">&nbsp;</div>

    <div class="w3-third" align="center">
      <input align="center" id="submit-btna" type="text" class="form-control" name="full" placeholder="Masukkan Nama Lengkap">
    </div>

    <div class="w3-third" align="center">&nbsp;</div>
    <div class="w3-third" align="center">&nbsp;</div>
    <div class="w3-third" align="center">&nbsp;</div>
    <div class="w3-third" align="center">&nbsp;</div>

    <div class="w3-third" align="center">
      <input align="center" id="submit-btna" type="text" class="form-control" name="uname" placeholder="Masukkan Username">
    </div>

    <div class="w3-third" align="center">&nbsp;</div>
    <div class="w3-third" align="center">&nbsp;</div>
    <div class="w3-third" align="center">&nbsp;</div>
    <div class="w3-third" align="center">&nbsp;</div>

    <div class="w3-third">
      <label for="Kewenangan"></label>
      <select id="submit-btna" class="form-control" name="kewe" >
      <option>OPD</option>
      <option value="Badan Kepegawaian, Pendidikan dan Pelatihan">Badan Kepegawaian, Pendidikan dan Pelatihan</option>
      <option value="Badan Keuangan Daerah">Badan Keuangan Daerah</option>
      <option value="Badan Penanggulangan Bencana Daerah">Badan Penanggulangan Bencana Daerah</option>
      <option value="Badan Perncanaan, Penelitian dan Pengembangan Daerah">Badan Perncanaan, Penelitian dan Pengembangan Daerah</option>   
      <option value="Dinas Kearsipan dan Perpustakaan">Dinas Kearsipan dan Perpustakaan</option>
      <option value="Dinas Kepemudaan dan Olahraga">Dinas Kepemudaan dan Olahraga</option>
      <option value="Dinas Kependudukan dan Pencatatan Sipil">Dinas Kependudukan dan Pencatatan Sipil</option>
      <option value="Dinas Kesehatan">Dinas Kesehatan</option>
      <option value="Dinas Komunikasi dan Informatika">Dinas Komunikasi dan Informatika</option>
      <option value="Dinas Lingkungan Hidup">Dinas Lingkungan Hidup</option>
      <option value="Dinas Pangan">Dinas Pangan</option>
      <option value="Dinas Pekerjaan Umum dan Penataan Ruang">Dinas Pekerjaan Umum dan Penataan Ruang</option>
      <option value="Dinas Pemberdayaan Masyarakat dan Desa">Dinas Pemberdayaan Masyarakat dan Desa</option>
      <option value="Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu">Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu</option>
      <option value="Dinas Pendidikan dan Kebudayaan">Dinas Pendidikan dan Kebudayaan</option>
      <option value="Dinas Pengendalian Penduduk, Keluarga Berencana (PPKB) dan Pemberdayaan Perempuan dan Perlindungan Anak (P3A)">Dinas Pengendalian Penduduk, Keluarga Berencana dan Pemberdayaan Perempuan dan Perlindungan Anak</option>
      <option value="Dinas Perdagangan, Koperasi, Usaha Kecil dan Menengah">Dinas Perdagangan, Koperasi, Usaha Kecil dan Menengah</option>
      <option value="Dinas Perhubungan">Dinas Perhubungan</option>
      <option value="Dinas Perindustrian dan Tenaga Kerja">Dinas Perindustrian dan Tenaga Kerja</option>
      <option value="Dinas Pertanian dan Perikanan">Dinas Pertanian dan Perikanan</option>
      <option value="Dinas Perumahan dan Kawasan Pemukiman">Dinas Perumahan dan Kawasan Pemukiman</option>
      <option value="Dinas Sosial">Dinas Sosial</option> 
      <option value="Inspektorat">Inspektorat</option>
      <option value="JDIH">JDIH</option>
      <option value="Kantor Kesbangpol">Kantor Kesbangpol</option>
      <option value="Perangkat Daerah">Perangkat Daerah</option>
      <option value="PPID">PPID</option>
      <option value="Satpol PP">Satpol PP</option>
      <option value="Sekertariat Daerah">Sekertariat Daerah</option>
      <option value="Sekertaris Daerah">Sekertaris Daerah</option>
      </select>
    </div> 

    <div class="w3-third" align="center">&nbsp;</div>
    <div class="w3-third" align="center">&nbsp;</div>
    <div class="w3-third" align="center">&nbsp;</div>
    <div class="w3-third" align="center">&nbsp;</div>

    <div class="w3-third" align="center">
      <input align="center" id="submit-btna" type="text" class="form-control" name="pass" placeholder="Masukkan Password">
    </div>

    <div class="w3-third" align="center">&nbsp;</div>
    <div class="w3-third" align="center">&nbsp;</div>
    <div class="w3-third" align="center">&nbsp;</div>
    <div class="w3-third" align="center">&nbsp;</div>

    <div class="w3-third" align="center">
      <form action="#"   >
        <button id="submit-btna" type="textarea" name="judul" style="display: inline">Submit</button>
      </form>
    </div>
    
    <div class="w3-third" align="center">&nbsp;</div>

  </div>
  <!-- END CONTENT -->

  <!-- DAFTAR ADMIN -->
  <div class="w3-half">

    <!--TITLE-->
    <div class="w3-col" align="left">
      <h2 style="padding-left:0">DAFTAR ADMIN</h2>
    </div>
    <!--END TITLE-->

    <!--CONTENT-->
    <div class="w3-col">
      &nbsp;
      <div class="table-responsive">
        <table class="table-striped table-bordered table-hoverable">
          <thead>
            <tr class="table-light-grey">
              <th>Username</th>
              <th>Nama Lengkap</th>
              <th>Kewenangan</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php
            // menampilkan combo box berisi kategori buku
            foreach ($users as $u_item):
            ?>
              <td><?php echo $u_item['username']?></td>
              <td><?php echo $u_item['nama']?></td>
              <td><?php if ($u_item['role'] == 'Administrator'){echo "<font color='blue'>".$u_item['role'];} else {echo "<font color='green'>".$u_item['role'];}?></td>
              <td><font color="red"><?php echo anchor('user/delete/'.$u_item['username'], '<svg height="25px" viewBox="-48 0 400 400" width="25px" xmlns="http://www.w3.org/2000/svg" fill="red"><path d="m89.199219 37c0-12.132812 9.46875-21 21.601562-21h88.800781c12.128907 0 21.597657 8.867188 21.597657 21v23h16v-23c0-20.953125-16.644531-37-37.597657-37h-88.800781c-20.953125 0-37.601562 16.046875-37.601562 37v23h16zm0 0"/><path d="m60.601562 407h189.199219c18.242188 0 32.398438-16.046875 32.398438-36v-247h-254v247c0 19.953125 14.15625 36 32.402343 36zm145.597657-244.800781c0-4.417969 3.582031-8 8-8s8 3.582031 8 8v189c0 4.417969-3.582031 8-8 8s-8-3.582031-8-8zm-59 0c0-4.417969 3.582031-8 8-8s8 3.582031 8 8v189c0 4.417969-3.582031 8-8 8s-8-3.582031-8-8zm-59 0c0-4.417969 3.582031-8 8-8s8 3.582031 8 8v189c0 4.417969-3.582031 8-8 8s-8-3.582031-8-8zm0 0"/><path d="m20 108h270.398438c11.046874 0 20-8.953125 20-20s-8.953126-20-20-20h-270.398438c-11.046875 0-20 8.953125-20 20s8.953125 20 20 20zm0 0"/></svg>'); ?></td>
            </tr>
            <?php 
            endforeach;
            ?>
        </table>
      </div>
    </div>

  </div>
  <!--END CONTENT-->
  <!-- END DAFTAR ADMIN -->

</div>

</body>
</html>