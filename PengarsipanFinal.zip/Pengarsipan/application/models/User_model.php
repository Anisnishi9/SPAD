<?php

class User_model extends CI_Model {

	public function getUserProfile($username){
		$query = $this->db->get_where('users', array('username' => $username));
		return $query->row_array();
	}
	// method untuk hapus data buku berdasarkan id
	public function delUser($id){
		$this->db->delete('users', array("username" => $id));
	}

	// method untuk insert data buku ke tabel 'books'
	public function insertUser($uname, $pass, $full, $kewe){
		$data = array(
			"username" => $uname,
			"passwd" => $pass,
			"nama" => $full,
			"role" => $kewe,
		);
		$query = $this->db->insert('users', $data);
		echo $query;
	}

	public function getAdmin(){
		$query = $this->db->get('users');
		return $query->result_array();
	}

	public function detailP($dat){
		$query = $this->db->query("SELECT namapeminjam, nippeminjam, departemen FROM peminjaman WHERE nomorarsip LIKE '$dat' ");
		return $query->result_array();
	}
	
}
?>